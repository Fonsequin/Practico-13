<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Iniciar Sesión</title>
    <!-- Ruta local a tu carpeta css -->
    <link rel="stylesheet" href="css/bulma.min.css">
	<link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<section class="section">
    <div class="container">
        <div class="columns is-centered">
            <div class="column is-4">
                <h2 class="title has-text-centered">Iniciar Sesión</h2>
                
                <!-- El action debe apuntar a login.php y el method debe ser POST -->
                <form action="login.php" method="POST">
                    
                    <div class="field">
                        <label class="label">Usuario</label>
                        <div class="control">
                            <!-- ⚠️ IMPORTANTE: name="login_usuario" -->
                            <input class="input" type="text" name="login_usuario" required autocomplete="username">
                        </div>
                    </div>
                    
                    <div class="field">
                        <label class="label">Contraseña</label>
                        <div class="control">
                            <!-- ⚠️ IMPORTANTE: name="login_clave" -->
                            <input class="input" type="password" name="login_clave" required autocomplete="current-password">
                        </div>
                    </div>
                    
                    <div class="field">
                        <div class="control">
                            <button class="button is-primary is-fullwidth" type="submit">Entrar</button>
                        </div>
                    </div>
                </form>
                
            </div>
        </div>
    </div>
</section>
</body>
</html>