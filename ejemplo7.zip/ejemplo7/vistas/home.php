<?php
require_once __DIR__ . "/../funciones.php";

verificar_sesion();

$pdo = conexion();

$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$registros_por_pagina = 10;
$inicio = ($pagina - 1) * $registros_por_pagina;

$total = $pdo->query("SELECT COUNT(*) FROM producto")->fetchColumn();
$dinero_total = $pdo->query("SELECT SUM(producto_precio * producto_stock) FROM producto")->fetchColumn();
$Npaginas = ceil($total / $registros_por_pagina);

$stmt = $pdo->prepare("SELECT * FROM producto LIMIT ?, ?");
$stmt->bindParam(1, $inicio, PDO::PARAM_INT);
$stmt->bindParam(2, $registros_por_pagina, PDO::PARAM_INT);
$stmt->execute();
$productos = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inicio</title>
    <link rel="stylesheet" href="css/bulma.min.css">
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>

<!-- header -->
<header class="encabezado">
    <img src="img/papa.png" class="logo">
    <p class="encabezado-titulo">Verduleria admin</p>
</header>

<!-- toda la parte del centro -->
<section class="section">
    <div class="container">
        <h1 class="title">Bienvenido, <?php echo limpiar_cadena($_SESSION['usuario']); ?></h1>
        <a href="logout.php" class="button is-danger">Cerrar Sesión</a>

        <h2 class="subtitle mt-5">Productos</h2>

        <table class="table is-fullwidth is-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Código</th>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Stock</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($productos as $p): ?>
                <tr>
                    <td><?php echo $p['producto_id']; ?></td>
                    <td><?php echo limpiar_cadena($p['producto_codigo']); ?></td>
                    <td><?php echo limpiar_cadena($p['producto_nombre']); ?></td>
                    <td>$<?php echo number_format($p['producto_precio'], 2); ?></td>
                    <td><?php echo $p['producto_stock']; ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- tarjetas -->
        <div class="tarjetas">
            <div class="tarjeta">
                <p class="tarjeta-titulo">Total de productos</p>
                <p class="tarjeta-valor"><?php echo $total; ?></p>
            </div>

            <div class="tarjeta">
                <p class="tarjeta-titulo">Ganancia maxima de los productos</p>
                <p class="tarjeta-valor">$<?php echo number_format($dinero_total, 2); ?> pesos</p>
            </div>
        </div>

        <?php
        $url = "index.php?vista=home&pagina=";
        echo paginador_tablas($pagina, $Npaginas, $url, 5);
        ?>
    </div>
</section>

<!-- footer -->
<footer class="pie">
    <p>© 2026 Gonzalo Fonseca Todos los derechos reservados</p>
</footer>

</body>
</html>