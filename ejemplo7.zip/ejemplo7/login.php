<?php
require_once "funciones.php"; // Asegura que session_start() y las funciones estén disponibles

// 1. Almacenando y limpiando datos del formulario
$usuario = limpiar_cadena($_POST['login_usuario'] ?? '');
$clave   = $_POST['login_clave'] ?? '';

// 2. Verificando campos obligatorios
if($usuario === "" || $clave === ""){
    echo '
    <div class="notification is-danger is-light">
        <strong>¡Ocurrió un error inesperado!</strong><br>
        No has llenado todos los campos que son obligatorios.
        <br><a href="index.php?vista=login" class="button is-small is-light mt-2">Volver</a>
    </div>';
    exit();
}

// 3. Verificando integridad de los datos (Regex)
if(verificar_datos("[a-zA-Z0-9]{4,20}", $usuario)){
    echo '
    <div class="notification is-danger is-light">
        <strong>¡Ocurrió un error inesperado!</strong><br>
        El USUARIO no coincide con el formato solicitado (4 a 20 caracteres alfanuméricos).
        <br><a href="index.php?vista=login" class="button is-small is-light mt-2">Volver</a>
    </div>';
    exit();
}

if(verificar_datos("[a-zA-Z0-9$@.-]{4,100}", $clave)){
    echo '
    <div class="notification is-danger is-light">
        <strong>¡Ocurrió un error inesperado!</strong><br>
        La CLAVE no coincide con el formato solicitado.
        <br><a href="index.php?vista=login" class="button is-small is-light mt-2">Volver</a>
    </div>';
    exit();
}

// 4. Consulta a la Base de Datos (USANDO CONSULTAS PREPARADAS PARA EVITAR INYECCIÓN SQL)
$pdo = conexion();
$stmt = $pdo->prepare("SELECT usuario_id, usuario_nombre, usuario_apellido, usuario_usuario, usuario_clave FROM usuario WHERE usuario_usuario = :usuario LIMIT 1");
$stmt->execute([':usuario' => $usuario]);
$datos_usuario = $stmt->fetch();

// 5. Verificando si el usuario existe y la contraseña es correcta
if($datos_usuario){
    
    /* 
     * ⚠️ IMPORTANTE SOBRE LA CONTRASEÑA:
     * Opción A (RECOMENDADA Y SEGURA): Si guardaste la clave con password_hash(), usa esta línea:
     */
    $clave_correcta = password_verify($clave, $datos_usuario['usuario_clave']);

    /* 
     * Opción B (SOLO SI TU BD TIENE CONTRASEÑAS EN TEXTO PLANO):
     * Si aún no encriptas las contraseñas en tu BD, descomenta la línea de abajo y comenta la de arriba.
     * (Nota: Deberías encriptarlas lo antes posible por seguridad).
     */
    // $clave_correcta = ($clave === $datos_usuario['usuario_clave']);


    if($clave_correcta){
        // ¡Credenciales correctas! Iniciamos sesión
        $_SESSION['id']       = $datos_usuario['usuario_id'];
        $_SESSION['nombre']   = $datos_usuario['usuario_nombre'];
        $_SESSION['apellido'] = $datos_usuario['usuario_apellido'];
        $_SESSION['usuario']  = $datos_usuario['usuario_usuario'];

        // Redirección limpia (Sin el parche de headers_sent)
        header("Location: index.php?vista=home");
        exit(); // Detiene la ejecución inmediatamente
    }
}

// Si llegamos aquí, es porque el usuario no existe o la clave es incorrecta
echo '
<div class="notification is-danger is-light">
    <strong>¡Ocurrió un error inesperado!</strong><br>
    Usuario o clave incorrectos.
    <br><a href="index.php?vista=login" class="button is-small is-light mt-2">Volver a intentar</a>
</div>';
?>