<?php
session_start();

# Conexión a la base de datos
function conexion(){
    $pdo = new PDO('mysql:host=localhost;dbname=pdo;charset=utf8mb4', 'root', '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    return $pdo;
}

# Verificar datos con regex
function verificar_datos($filtro, $cadena){
    return !preg_match("/^".$filtro."$/", $cadena);
}

# Limpiar cadenas (para mostrar en HTML)
function limpiar_cadena($cadena){
    return htmlspecialchars(trim(stripslashes($cadena)), ENT_QUOTES, 'UTF-8');
}

# Verificar si el usuario está logueado
function verificar_sesion(){
    if(!isset($_SESSION['id']) || empty($_SESSION['id'])){
        header("Location: index.php?vista=login");
        exit();
    }
}

# Paginador simple
function paginador_tablas($pagina, $Npaginas, $url, $botones){
    $tabla = '<nav class="pagination is-centered is-rounded">';
    
    if($pagina <= 1){
        $tabla .= '<a class="pagination-previous is-disabled" disabled>Anterior</a>';
    } else {
        $tabla .= '<a class="pagination-previous" href="'.$url.($pagina-1).'">Anterior</a>';
    }
    
    $tabla .= '<ul class="pagination-list">';
    $ci = 0;
    for($i = $pagina; $i <= $Npaginas; $i++){
        if($ci >= $botones) break;
        $clase = ($pagina == $i) ? 'pagination-link is-current' : 'pagination-link';
        $tabla .= '<li><a class="'.$clase.'" href="'.$url.$i.'">'.$i.'</a></li>';
        $ci++;
    }
    $tabla .= '</ul>';
    
    if($pagina == $Npaginas){
        $tabla .= '<a class="pagination-next is-disabled" disabled>Siguiente</a>';
    } else {
        $tabla .= '<a class="pagination-next" href="'.$url.($pagina+1).'">Siguiente</a>';
    }
    
    return $tabla . '</nav>';
}
?>