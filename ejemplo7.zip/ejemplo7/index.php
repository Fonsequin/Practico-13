<?php
require_once __DIR__ . "/funciones.php";

$vista = $_GET['vista'] ?? 'login';

// Si no está logueado y no está en login, redirigir
if($vista !== 'login' && !isset($_SESSION['id'])){
    header("Location: index.php?vista=login");
    exit();
}

// Si está logueado y va a login, redirigir a home
if($vista === 'login' && isset($_SESSION['id'])){
    header("Location: index.php?vista=home");
    exit();
}

// Cargar la vista correspondiente
switch($vista){
    case 'login':
        include __DIR__ . "/vistas/login_form.php";
        break;
    case 'home':
        include __DIR__ . "/vistas/home.php";
        break;
    default:
        echo "Vista no encontrada";
}
?>